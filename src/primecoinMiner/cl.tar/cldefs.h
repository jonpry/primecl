
#define STRIDE 1024

typedef struct 
{
	uint32_t total[2][STRIDE];
	uint32_t state[8][STRIDE];
	uint8_t buffer[64][STRIDE];
	uint32_t W[64][STRIDE];
	uint8_t msglen[8][STRIDE];
	uint8_t padding[64][STRIDE];
} sha256_context;


typedef struct  
{
	uint32_t	version[STRIDE];
	uint8_t		prevBlockHash[32][STRIDE];
	uint8_t		merkleRoot[32][STRIDE];
	uint32_t	timestamp[STRIDE];
	uint32_t	nBits[STRIDE];
	uint32_t	nonce[STRIDE];
/*	// GetHeaderHash() goes up to this offset (4+32+32+4+4+4=80 bytes)
	uint256 blockHeaderHash;
	//CBigNum bnPrimeChainMultiplierBN; unused
	mpz_class mpzPrimeChainMultiplier;
	// other
	serverData_t serverData;
	uint32 threadIndex; // the index of the miner thread
	bool xptMode;*/
}primecoinBlock_t;

