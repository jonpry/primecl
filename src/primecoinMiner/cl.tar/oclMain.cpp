/* Simple Hello World for OpenCL, written in C.
 * For real code, check for errors. The error code is stored in all calls here,
 * but no checking is done, which is certainly bad. It'll likely simply crash
 * right after a failing call.
 *
 * On GNU/Linux with nVidia OpenCL, program builds with -lOpenCL.
 * Not sure about other platforms.
 */

#include <stdio.h>
#include <string.h>

#include <CL/cl.h>

#include "cldefs.h"

char *loadfile(const char* fname, size_t *sz_ptr){
	char *ret;
	FILE *fil=fopen(fname,"r");
	fseek(fil, 0L, SEEK_END);
	size_t sz = ftell(fil);

	fseek(fil, 0L, SEEK_SET);
	ret = new char[sz];
	fread(ret, sz, 1, fil);
	fclose(fil);
	
	*sz_ptr = sz;
	
	return ret;
}

int main() {
	char buf[]="Hello, World!";
	size_t srcsize, worksize=strlen(buf);
	
	cl_int error;
	cl_platform_id platform;
	cl_device_id device;
	cl_uint platforms, devices;

	// Fetch the Platform and Device IDs; we only want one.
	error=clGetPlatformIDs(1, &platform, &platforms);
printf("Err1: %d\n", error);
	error=clGetDeviceIDs(platform, CL_DEVICE_TYPE_ALL, 1, &device, &devices);
printf("Err2: %d\n", error);
	cl_context_properties properties[]={
		CL_CONTEXT_PLATFORM, (cl_context_properties)platform,
		0};
	// Note that nVidia's OpenCL requires the platform property
	cl_context context=clCreateContext(properties, 1, &device, NULL, NULL, &error);
printf("Err3: %d\n", error);
	cl_command_queue cq = clCreateCommandQueue(context, device, 0, &error);
	
	const char *src=loadfile("rot13.cl",&srcsize);

	printf("%p\n",src);

	const char *srcptr[]={src};
	// Submit the source code of the rot13 kernel to OpenCL
	cl_program prog=clCreateProgramWithSource(context,
		1, srcptr, &srcsize, &error);
	printf("Err: %d\n", error);

	// and compile it (after this we could extract the compiled version)
	error=clBuildProgram(prog, 0, NULL, "-I ./", NULL, NULL);
	delete src;

	if (error == CL_BUILD_PROGRAM_FAILURE) {
    		// Determine the size of the log
    		size_t log_size;
    		clGetProgramBuildInfo(prog, device, CL_PROGRAM_BUILD_LOG, 0, NULL, &log_size);

    		// Allocate memory for the log
    		char *log = (char *) malloc(log_size);

    		// Get the log
    		clGetProgramBuildInfo(prog, device, CL_PROGRAM_BUILD_LOG, log_size, log, NULL);

    		// Print the log
    		printf("%s\n", log);
	}else{
		size_t sizes[16];
		clGetProgramInfo(prog, CL_PROGRAM_BINARY_SIZES, 8, &sizes, 0);
		printf("%ld\n", sizes[0]);
		char **progs = new char *;
		progs[0] = new char[sizes[0]];
		clGetProgramInfo(prog, CL_PROGRAM_BINARIES, 8, progs, 0);
		
	//	printf("%s\n", progs[0]);
		//clLogPtx(prog, device, "oclConvolution.ptx");
	}

	printf("Err: %d\n", error);

/*
    (   __global    sha256_context*    ctx
    ,   __global uint8_t hashOutput[32][STRIDE]	
    ,   __global primecoinBlock_t *blocks
    ,   __global uint8_t temp1[][STRIDE]		
    ,   unsigned length	 */

	// Allocate memory for the kernel to work with
	cl_mem sha_mem, hash_mem, block_mem, temp_mem;
	sha_mem=clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(sha256_context), NULL, &error);
	hash_mem=clCreateBuffer(context, CL_MEM_READ_WRITE, 32*STRIDE, NULL, &error);
	block_mem=clCreateBuffer(context, CL_MEM_READ_WRITE, sizeof(primecoinBlock_t), NULL, &error);
	temp_mem=clCreateBuffer(context, CL_MEM_READ_WRITE, 80*STRIDE, NULL, &error);
	
	unsigned length = 512;

	// get a handle and map parameters for the kernel
	cl_kernel k_rot13=clCreateKernel(prog, "rot13", &error);
	clSetKernelArg(k_rot13, 0, sizeof(sha_mem), &sha_mem);
	clSetKernelArg(k_rot13, 1, sizeof(hash_mem), &hash_mem);
	clSetKernelArg(k_rot13, 2, sizeof(block_mem), &block_mem);
	clSetKernelArg(k_rot13, 3, sizeof(temp_mem), &temp_mem);
	clSetKernelArg(k_rot13, 4, sizeof(length), &length);



	// Target buffer just so we show we got the data from OpenCL
	unsigned char buf2[32*STRIDE] = {0};
	unsigned char buf3[32*STRIDE] = {0};
	

	primecoinBlock_t* lblocks = new primecoinBlock_t;
	memset(lblocks,0,sizeof(primecoinBlock_t));
	
	unsigned char hashin[32 * STRIDE] = {0};
	hashin[0] = 0xFF;
	hashin[STRIDE] = 0xEE;
	hashin[2*STRIDE] = 0xDD;
	hashin[3*STRIDE] = 0xCC;


	// Send input data to OpenCL (async, don't alter the buffer!)
	error=clEnqueueWriteBuffer(cq, block_mem, CL_FALSE, 0, sizeof(primecoinBlock_t), lblocks, 0, NULL, NULL);
	error=clEnqueueWriteBuffer(cq, hash_mem, CL_FALSE, 0, 32 * STRIDE, hashin, 0, NULL, NULL);

	// Perform the operation
	worksize = 512;
	error=clEnqueueNDRangeKernel(cq, k_rot13, 1, NULL, &worksize, &worksize, 0, NULL, NULL);
	// Read the result back into buf2
	printf("Err: %d\n", error);
	
	error=clEnqueueReadBuffer(cq, hash_mem, CL_FALSE, 0, 32 * STRIDE, buf2, 0, NULL, NULL);
	error=clEnqueueReadBuffer(cq, temp_mem, CL_FALSE, 0, 32 * STRIDE, buf3, 0, NULL, NULL);
	printf("Err: %d\n", error);

	// Await completion of all the above
	error=clFinish(cq);

	printf("Err: %d\n", error);
	
	// Finally, output out happy message.
	int i;
	for(i=0; i < 32; i++){
		printf("%2.2X", buf3[i*STRIDE]);
	}
	printf("\n");

	for(i=0; i < 32; i++){
		printf("%2.2X", buf2[i*STRIDE]);
	}
	printf("\n");

}
